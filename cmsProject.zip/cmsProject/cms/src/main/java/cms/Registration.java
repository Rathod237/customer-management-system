package cms;
//import cms.db.dbConnection;
//user_id,user_name,password,role ====users is table

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import javax.management.relation.Role;

public class Registration {
private String userId; //auto increment indb
private String userName;
private String userPassword;
private String userRole;
//register method 
public void register() throws SQLException{
	System.out.println("adding new user:");
	//taking input for user registration
	Scanner scan = new Scanner(System.in);
	System.out.print("enter username : ");
	userName = scan.nextLine();
	System.out.print("enter user password : ");
	userPassword = scan.nextLine();
	System.out.print("enter user Role : ");
	userRole = scan.nextLine();
	
	//insert userdata into table
	String insert ="insert into cmsusers  (userId,userName,userPassword,userRole) values (seq_id.nextval,?,?,?)";
	PreparedStatement prepareStmt =CustomerManageSystem.connectdb.conn.prepareStatement(insert);
	prepareStmt.setString(1, userName);
	 prepareStmt.setString(2, userPassword);
	 prepareStmt.setString(3, userRole);
	 prepareStmt.execute();
	 System.out.println("User "+userName+" added successfully ");
	
}
public void addNewUser() throws SQLException {
	register();
}
public void viewAllUsers() throws SQLException {
	String serachAllUser = "select userID,userName,userrole from cmsusers ";
	PreparedStatement prepareStmt = CustomerManageSystem.connectdb.conn.prepareStatement(serachAllUser);

	ResultSet allUsers = prepareStmt.executeQuery();
	System.out.println("all user's are: ");
	System.out.println("----------------------------------");
	System.out.println("id  name    role");
	System.out.println("---------------------------------");
	while (allUsers.next()) {

		System.out.print(allUsers.getInt(1) + " ");
		System.out.print(allUsers.getString(2) + " ");
		System.out.print(" " + allUsers.getString(3) + " ");
		System.out.println("\n-----------------------------");
	}
	
}


//String registerQuery ="insert into table user values(userId,userName,userPassword,userRole)"; 
}
