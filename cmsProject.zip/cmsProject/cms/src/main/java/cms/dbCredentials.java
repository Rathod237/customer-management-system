package cms;

public class dbCredentials {
	private String driverClassLocation = "oracle.jdbc.OracleDriver";
	private String databaseUrl = "jdbc:oracle:thin:@localhost:1521:xe";
	private String userName = "rathod";
	private String userPassword ="rathods";
	public String getDriverClassLocation() {
		return driverClassLocation;
	}
	public void setDriverClassLocation(String driverClassLocation) {
		this.driverClassLocation = driverClassLocation;
	}
	public String getDatabaseUrl() {
		return databaseUrl;
	}
	public void setDatabaseUrl(String databaseUrl) {
		this.databaseUrl = databaseUrl;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserPassword() {
		return userPassword;
	}
	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}
	
}
